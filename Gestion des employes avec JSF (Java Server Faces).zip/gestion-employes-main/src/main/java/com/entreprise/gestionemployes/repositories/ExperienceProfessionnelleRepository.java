package com.entreprise.gestionemployes.repositories;

import com.entreprise.gestionemployes.entities.ExperienceProfessionnelle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExperienceProfessionnelleRepository extends JpaRepository<ExperienceProfessionnelle, Integer> {

}
