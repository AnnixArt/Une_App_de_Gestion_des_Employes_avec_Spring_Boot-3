package com.entreprise.gestionemployes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionEmployesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionEmployesApplication.class, args);
	}

}
